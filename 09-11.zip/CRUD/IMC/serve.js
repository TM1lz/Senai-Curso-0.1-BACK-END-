// Importa o módulo express para criar o servidor
const express = require('express');
const app = express();  // Cria uma instância do express para configurar as rotas
app.use(express.json());  // Middleware do express para interpretar os corpos de requisição no formato JSON

// Rota POST para calcular o IMC de uma pessoa, com parâmetros na URL: nome, peso e altura
app.post('/calcular-imc/:nome/:peso/:altura', (req, res) => {
    // Extrai o nome, peso e altura da URL
    let nome = req.params.nome;      // O nome da pessoa é extraído dos parâmetros da URL
    let peso = req.params.peso;      // O peso da pessoa é extraído dos parâmetros da URL
    let altura = req.params.altura;  // A altura da pessoa é extraída dos parâmetros da URL

    // Validação dos dados de entrada (peso e altura)
    // Verifica se os parâmetros peso e altura são válidos: não nulos, numéricos e dentro dos limites esperados
    if (!peso || !altura || isNaN(peso) || isNaN(altura) || peso <= 0 || altura <= 0 || altura >= 3 || peso >= 300) {
        // Se alguma condição falhar, retorna uma mensagem de erro
        return res.send('Peso e altura são obrigatórios e devem ser válidos.');
    }

    // Definindo a classe Pessoa que representa uma pessoa e seus atributos (nome, peso, altura)
    class Pessoa {
        constructor(nome, altura, peso) {
            this.nome = nome;   // Atribui o nome passado como argumento
            this.altura = altura; // Atribui a altura passada como argumento
            this.peso = peso;     // Atribui o peso passado como argumento
        }

        // Método para calcular o IMC (Índice de Massa Corporal)
        calcularIMC() {
            // Fórmula do IMC: IMC = peso / (altura * altura)
            const imc = this.peso / (this.altura * this.altura);
            return imc;  // Retorna o IMC calculado
        }

        // Método para classificar o IMC em diferentes categorias
        classificarIMC(imc) {
            let classificacao;  // Variável que vai armazenar a classificação do IMC

            // Classificação do IMC baseada nos intervalos definidos pela OMS
            if (imc < 18.5) {
                classificacao = 'Abaixo do peso';        // IMC abaixo de 18.5
            } else if (imc < 24.9) {
                classificacao = 'Peso normal';          // IMC entre 18.5 e 24.9
            } else if (imc < 29.9) {
                classificacao = 'Sobrepeso';            // IMC entre 25.0 e 29.9
            } else if (imc < 34.9) {
                classificacao = 'Obesidade grau 1';     // IMC entre 30.0 e 34.9
            } else if (imc < 39.9) {
                classificacao = 'Obesidade grau 2';     // IMC entre 35.0 e 39.9
            } else {
                classificacao = 'Obesidade grau 3';     // IMC acima de 40.0
            }

            return classificacao;  // Retorna a classificação do IMC
        }
    }

    // Cria uma instância da classe Pessoa com os dados passados na URL
    const pessoa = new Pessoa(nome, altura, peso);

    // Calcula o IMC da pessoa utilizando o método calcularIMC() da classe Pessoa
    const imc = pessoa.calcularIMC();

    // Classifica o IMC da pessoa utilizando o método classificarIMC() da classe Pessoa
    const classificacaoIMC = pessoa.classificarIMC(imc);

    // Retorna a resposta para o cliente em formato JSON, incluindo nome, peso, altura, IMC e sua classificação
    res.json({
        nome: pessoa.nome,              // Nome da pessoa
        peso: pessoa.peso,              // Peso da pessoa
        altura: pessoa.altura,          // Altura da pessoa
        imc: imc.toFixed(2),            // IMC calculado (com 2 casas decimais)
        classificacaoIMC,               // Classificação do IMC
    });
});

// Inicializa o servidor na porta 8081
app.listen(8081, () => {
    console.log("Servidor iniciado na porta 8081");  // Log de confirmação de que o servidor está em execução
});

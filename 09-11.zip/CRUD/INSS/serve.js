// Importa o módulo express para criar o servidor
const express = require('express');
const app = express();  // Cria uma instância do express para configurar as rotas

// Middleware para interpretar o corpo das requisições em formato JSON
app.use(express.json());

// Rota GET para calcular o salário líquido com base no salário bruto
app.get('/calcular-salario/:salario', (req, res) => {
    let salarioBruto = parseFloat(req.params.salario);  // Converte o parâmetro de salário para número (caso seja uma string)

    // Verifica se o salário bruto é um valor numérico válido
    if (isNaN(salarioBruto) || salarioBruto <= 0) {
        return res.status(400).json({ erro: 'Salário bruto inválido.' });  // Se o salário for inválido, retorna um erro
    }

    // Função para calcular o INSS com base no salário bruto
    function calcularINSS(salarioBruto) {
        let inss;
        // Faixas de INSS conforme o salário bruto
        if (salarioBruto <= 1212.00) {
            inss = salarioBruto * 0.075;
        } else if (salarioBruto <= 2427.35) {
            inss = salarioBruto * 0.09;
        } else if (salarioBruto <= 3641.03) {
            inss = salarioBruto * 0.12;
        } else if (salarioBruto <= 7087.22) {
            inss = salarioBruto * 0.14;
        } else {
            inss = 7087.22 * 0.14;  // Aplica o valor máximo para INSS (o teto de contribuição)
        }
        return inss;
    }

    // Função para calcular o IRPF com base no salário bruto e INSS
    function calcularIRPF(salarioBruto, inss) {
        const salarioBase = salarioBruto - inss;  // Salário base é o salário bruto após desconto do INSS
        let irpf;
        // Faixas de IRPF com base no salário base
        if (salarioBase <= 1903.98) {
            irpf = 0;
        } else if (salarioBase <= 2826.65) {
            irpf = salarioBase * 0.075 - 142.80;
        } else if (salarioBase <= 3751.05) {
            irpf = salarioBase * 0.15 - 354.80;
        } else if (salarioBase <= 4664.68) {
            irpf = salarioBase * 0.225 - 636.13;
        } else {
            irpf = salarioBase * 0.275 - 869.36;
        }
        return irpf;
    }

    // Função principal que calcula o salário líquido
    function calcularSalarioLiquido(salarioBruto) {
        // Chama as funções para calcular o INSS e o IRPF
        const inss = calcularINSS(salarioBruto);
        const irpf = calcularIRPF(salarioBruto, inss);
        const salarioLiquido = salarioBruto - inss - irpf;  // Subtrai o INSS e o IRPF do salário bruto
        return { salarioLiquido, inss, irpf };  // Retorna o salário líquido e os descontos
    }

    // Calcula o salário líquido e os descontos com base no salário bruto
    const { salarioLiquido, inss, irpf } = calcularSalarioLiquido(salarioBruto);

    // Retorna a resposta como um JSON com o salário bruto, descontos (INSS e IRPF) e salário líquido
    res.json({
        salarioBruto,  // Salário bruto fornecido
        descontos: {
            inss,         // Desconto de INSS
            impostoRenda: parseFloat(irpf.toFixed(2) ) // Desconto do Imposto de Renda (IRPF)
        },
        salarioLiquido  // Salário líquido após descontos
    });
});

// Inicia o servidor na porta 8081
app.listen(8081, () => {
    console.log("Servidor iniciado na porta 8081");  // Log indicando que o servidor foi iniciado
});

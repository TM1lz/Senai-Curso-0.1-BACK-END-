// Importa o módulo express para criar o servidor
const express = require('express');
const app = express(); // Cria uma instância do express para configurar as rotas
const port = 8081; // Define a porta que o servidor vai usar
const fs = require('fs'); // Importa o módulo para manipular o sistema de arquivos
const path = require('path'); // Importa o módulo para trabalhar com caminhos de arquivos

// Função assíncrona para garantir que o arquivo de usuarios exista
// Se o arquivo não existir, ele cria com um array vazio "[]"
const criarArquivoSeNaoExiste = async (caminho) => {
    // Verifica se o arquivo já existe
    if (!fs.existsSync(caminho)) {
        try {
            // Cria o arquivo e inicializa com um array vazio (representando usuarios vazias)
            fs.writeFileSync(caminho, "[]");
            console.log(`Arquivo de usuários criado com sucesso: ${caminho}`);
        } catch (err) {
            // Caso haja um erro ao criar o arquivo, loga no console
            console.error("Erro ao criar o arquivo de usuários: ", err);
        }
    }
};

// Middleware do Express para interpretar corpos de requisições JSON
app.use(express.json());

// Rota principal que serve uma mensagem simples sobre as rotas disponíveis
app.get("/", (req, res) => {
    res.send("Rotas : /lista , /add , /editarnome e /delete");
});

// Rota para retornar a lista de usuarios, que é um arquivo JSON
app.get("/listar", (req, res) => {
    // Envia o arquivo "listaDeusuarios.json" como resposta
    res.sendFile(path.join(__dirname, "/listaDeusuarios.json"));
});

// Rota para adicionar um usuário (POST)
app.post("/add/:nome/:idade", async (req, res) => {
    let nome = req.params.nome; // Obtém o nome da usuario da URL
    let idade = req.params.idade; // Obtém a idade da usuario da URL
    const caminho = path.join(__dirname, "/listaDeusuarios.json"); // Caminho do arquivo JSON

    // Verifica se nome e idade foram passados na URL
    if (!nome || !idade) {
        return res.status(400).send('Nome e idade são obrigatórios.');
    }

    try {
        // Lê o arquivo JSON contendo as usuários
        const usuarios = JSON.parse(await fs.promises.readFile(caminho, 'utf8'));

        // Cria a nova usuário com nome, idade e status inicializado como 0
        let novaUsuario = { nome, idade, status: 0 };

        // Adiciona a nova usuário ao array de usuários
        usuarios.push(novaUsuario);

        // Escreve o array de usuários de volta para o arquivo JSON
        await fs.promises.writeFile(caminho, JSON.stringify(usuarios, null, 2));

        // Responde ao cliente com status 200 e mensagem de sucesso
        res.status(200).send(`Usuário adicionado com sucesso!\nNome: ${nome}\nIdade: ${idade}`);
        console.log(`Usuário ${nome} adicionado com sucesso!`);

    } catch (err) {
        // Em caso de erro ao manipular o arquivo, loga o erro e responde com status 500
        console.error("Erro ao adicionar o usuário: ", err);
        res.status(500).send("Erro ao adicionar o usuário.");
    }
});

// Rota para atualizar o nome de uma usuário (PUT)
app.put("/editarnome/:nome/:nome2", async (req, res) => {
    let nome = req.params.nome; // Nome atual da usuário
    let nome2 = req.params.nome2; // Novo nome para a usuário
    const caminho = path.join(__dirname, "/listaDeusuarios.json"); // Caminho do arquivo JSON

    try {
        // Lê o arquivo JSON contendo as usuários
        const usuarios = JSON.parse(await fs.promises.readFile(caminho, 'utf8'));

        // Procura pela usuário que tem o nome igual ao 'nome' passado
        const usuario = usuarios.find(t => t.nome === nome);

        // Se a usuário não for encontrada, responde com erro 404 (não encontrado)
        if (!usuario) {
            console.log(`Usuário não encontrado para alteração: ${nome}`);
            return res.status(404).send('Usuário não encontrado');
        }

        // Atualiza o nome da usuário com o novo nome
        usuario.nome = nome2;

        // Escreve o array de usuários de volta no arquivo JSON
        await fs.promises.writeFile(caminho, JSON.stringify(usuarios, null, 2));

        // Responde com sucesso
        res.status(200).send('Usuário atualizado com sucesso!');
        console.log(`Nome do usuário ${nome} alterado para ${nome2}`);

    } catch (err) {
        // Caso haja um erro ao atualizar a usuário, loga o erro e responde com status 500
        console.error("Erro ao atualizar o usuário: ", err);
        res.status(500).send("Erro ao atualizar o usuário.");
    }
});

// Rota para excluir uma usuário (DELETE)
app.delete("/delete/:nome", async (req, res) => {
    let nome = req.params.nome; // Nome da usuário a ser excluída
    const caminho = path.join(__dirname, "/listaDeusuarios.json"); // Caminho do arquivo JSON

    try {
        // Lê o arquivo JSON contendo as usuários
        const usuarios = JSON.parse(await fs.promises.readFile(caminho, 'utf8'));

        // Encontra o índice da usuário a ser excluída
        const index = usuarios.findIndex(t => t.nome === nome);

        // Se a usuário não for encontrada, responde com erro 404
        if (index === -1) {
            console.log(`Usuário não encontrado para exclusão: ${nome}`);
            return res.status(404).send('Usuário não encontrado');
        }

        // Remove a usuário do array
        usuarios.splice(index, 1);

        // Escreve o array de usuários atualizado no arquivo JSON
        await fs.promises.writeFile(caminho, JSON.stringify(usuarios, null, 2));

        // Responde com sucesso
        res.status(200).send('Usuário excluído com sucesso!');
        console.log(`Usuário ${nome} excluído com sucesso!`);

    } catch (err) {
        // Caso haja um erro ao excluir a usuário, loga o erro e responde com status 500
        console.error("Erro ao excluir o usuário: ", err);
        res.status(500).send("Erro ao excluir o usuário.");
    }
});

// Inicia o servidor na porta especificada
app.listen(port, async () => {
    await criarArquivoSeNaoExiste(path.join(__dirname, "/listaDeusuarios.json"));
    console.log(`Servidor rodando em: http://localhost:${port}`);
});



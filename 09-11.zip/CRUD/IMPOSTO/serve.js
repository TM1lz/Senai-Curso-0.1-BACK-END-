// Importa o módulo express para criar o servidor
const express = require('express');

// Cria uma instância do express para configurar as rotas
const app = express();

// Middleware para interpretar o corpo das requisições em formato JSON
// Esse middleware permite que o servidor leia dados em formato JSON enviados no corpo da requisição
app.use(express.json());

// Define a rota POST para calcular o imposto com base no tipo de produto e no preço
app.post('/calcular-imposto/:tipo/:nome/:preco', (req, res) => {
    // Obtém os parâmetros passados na URL: 'nome', 'preco' e 'tipo'
    let tipo = req.params.tipo.toLowerCase();
    let nome = req.params.nome;       // Nome do produto
    let preco = parseFloat(req.params.preco); 
      // Preço do produto (converte para número)
      // Tipo do produto, converte para minúsculo para comparação

    // Verifica se o preço é um número válido
    if (isNaN(preco) || preco <= 0) {
        return res.status(400).send('Erro: O preço deve ser um número válido e maior que 0.');
    }

    // Variável para armazenar o valor do imposto
    let imposto;

    // Utiliza uma estrutura switch para calcular o imposto conforme o tipo de produto
    switch (tipo) {
        case 'eletronico':
            imposto = preco * 0.2;  // Imposto de 20% para produtos eletrônicos
            break;
        case 'alimenticio':
            imposto = preco * 0.05;  // Imposto de 5% para produtos alimentícios
            break;
        case 'vestuario':
            imposto = preco * 0.1;   // Imposto de 10% para produtos de vestuário
            break;
        default:
            // Caso o tipo do produto seja inválido, responde com erro 400 e uma mensagem
            return res.status(400).send('Erro: Tipo de produto inválido. Os tipos válidos são: eletronico, alimenticio, vestuario.');
    }

    // Calcula o preço final com o imposto aplicado
    const precoFinal = preco + imposto;

    // Retorna a resposta em formato JSON, com o nome do produto, preço original, imposto aplicado e preço final
    res.json({
        nome,
        precoOriginal: preco,
        impostoAplicado: imposto,
        precoFinal
    });
});

// Inicia o servidor na porta 8081
app.listen(8081, () => {
    console.log("Servidor iniciado na porta 8081");
});

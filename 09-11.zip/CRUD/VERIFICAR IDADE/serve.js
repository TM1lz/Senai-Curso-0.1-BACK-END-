// Importa o módulo express para criar o servidor
const express = require('express');
// Cria uma instância do express para configurar as rotas
const app = express();  

// Middleware para interpretar o corpo das requisições em formato JSON
// Isso permite que o servidor entenda dados enviados no corpo da requisição em JSON, caso necessário em outras rotas
app.use(express.json());

// Define a rota para verificar se a pessoa é maior ou menor de idade com base nos parâmetros 'nome' e 'idade' na URL
app.get("/verificarIdade/:nome/:idade", (req, res) => {
    // Obtém o parâmetro 'nome' da URL (req.params.nome)
    // O parâmetro 'nome' representa o nome da pessoa
    let nome = req.params.nome;

    // Obtém o parâmetro 'idade' da URL (req.params.idade)
    // O parâmetro 'idade' representa a idade da pessoa, mas será convertida para número
    let idade = req.params.idade;

    // Verifica se os parâmetros 'nome' ou 'idade' não foram fornecidos na URL
    if (!nome || !idade) {
        // Se algum parâmetro estiver faltando, retorna uma resposta de erro com status 400 (Bad Request)
        return res.status(400).send("Erro: Parâmetros 'nome' e 'idade' são obrigatórios.");
    }

    // Converte o valor de 'idade' de string para um número inteiro
    idade = parseInt(idade);

    // Verifica se a conversão de 'idade' resultou em um valor numérico válido
    if (isNaN(idade)) {
        // Se 'idade' não for um número válido (NaN), retorna uma resposta de erro
        return res.status(400).send("Erro: A idade deve ser um número válido.");
    }

    // Verifica se a idade é maior ou igual a 18 (maior de idade)
    if (idade >= 18) {
        // Se for maior ou igual a 18 anos, responde com uma mensagem indicando que a pessoa é maior de idade
        res.send(`Olá ${nome}, você tem ${idade} anos e é maior de idade.`);
    } else {
        // Se for menor que 18 anos, responde com uma mensagem indicando que a pessoa é menor de idade
        res.send(`Olá ${nome}, você tem ${idade} anos e é menor de idade.`);
    }
});

// Inicia o servidor e escuta na porta 8081 para requisições
// O servidor ficará aguardando requisições na URL http://localhost:8081
app.listen(8081, () => {
    // Exibe uma mensagem no console informando que o servidor foi iniciado corretamente
    console.log("Servidor iniciado na porta 8081");
});
